#!/bin/sh

export ANT_OPTS=-Xmx256m

export MY_PROJECT_NAME=dfclient

export DBFLUTE_HOME=../mydbflute/dbflute-0.9.5
