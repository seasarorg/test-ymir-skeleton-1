#!/bin/sh

export ANT_OPTS=-Xmx256m

export MY_PROJECT_NAME=fullProperties

#export DBFLUTE_HOME=../mydbflute/dbflute-x.x.x
