#!/bin/sh

export ANT_OPTS=-Xmx256m

export MY_PROJECT_NAME=minimumProperties

#export DBFLUTE_HOME=../mydbflute/dbflute-x.x.x
