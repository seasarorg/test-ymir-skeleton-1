Directory for Data

playsql
  |-data
     |-common
     |  |-xls
     |     |-Xxx.xls
     |     |-default-value.txt
     |-ut
        |-xls
           |-Yyy.xls  
           |-default-value.txt