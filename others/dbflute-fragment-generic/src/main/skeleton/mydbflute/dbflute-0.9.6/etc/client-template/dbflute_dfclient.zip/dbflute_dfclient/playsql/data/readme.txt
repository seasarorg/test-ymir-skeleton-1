Directory for Data

playsql
  |-data
     |-common
     |  |-xls
     |     |-Xxx.xls
     |     |-defaultValueMap.dataprop
     |-ut
        |-xls
           |-Yyy.xls  
           |-defaultValueMap.dataprop